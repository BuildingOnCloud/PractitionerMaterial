From certifications, regulations to frameworks, AWS has you covered. <br>Some of those included are:

-   Cyber Essentials Plus (UK)
-   DoD SRG (US)
-   FIPS (US)
-   ISO 9001
-   CISPE
-   GLBA
-   UK Data Protection Act
-   EU Data Protection Directive
-   FFIEC
-   G-Cloud (UK)
-   NIST
-   UK Cloud Security Principles