Amazon Elastic Compute Cloud (Amazon EC2) is a web service that provides secure, resizable compute capacity in the cloud. It is designed to make web-scale cloud computing easier for developers. There are several [[EC2 Instance Types]], depends of the kind of work to do.

Additionally AWS have a [[EC2 Pricing]] model to apply charges.

The EC2 instances are ruled by  [[Security Groups]] to allow access to them.