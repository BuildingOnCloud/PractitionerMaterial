AWS Professional Services and the AWS Partner Network can help you create more comprehensive solutions to security problems, everything from strategic advice, deployments, to re-engineering your security processes. Example engagements include:

-   Enterprise Security Architecture. <br>Evaluate the nature of the workloads you are deploying in AWS, along with your security needs and define an architecture and set of security controls that will protect your data and workloads according to best practices.

-   Policies and Controls-Mapping. <br>Examine your requirements based upon your security policy and any third party or regulatory mandates and provide detailed recommendations on how to satisfy those requirements and demonstrate compliance.

-   Security Operations Playbook. <br>Define the right organizational structures and processes to ensure that security controls are working correctly, as well as detect and respond to security issues that arise within your AWS environment

-   Business Unit Workshops. <br>Work with IT and Business Leaders across your organization to understand their plans and strategies around Cloud adoption, educate them on the best way to satisfy their requirements while minimizing risks to the organization, and devise an organization wide security framework for deploying workloads on AWS.