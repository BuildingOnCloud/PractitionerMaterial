AWS Trusted Advisor is an online resource that helps you provision your resources following best practices to help reduce cost, increase performance and fault tolerance, and improve security by optimizing your AWS environment. While the four core checks are available to all AWS customers, the full power of AWS Trusted Advisor is available with Business and Enterprise Support plans.

-   Guidance on getting the optimal performance and availability based on your requirements
-   Opportunities to reduce your monthly spend and retain or increase productivity
-   Best practices to help increase security

Trusted Advisor inspects your AWS environment to finds opportunities that can save you money, improve your system performance, increase your application reliability, and help you implement security best practices. Since 2013, customers have viewed over 2.6 million best-practice recommendations and realized over $350 million in estimated cost reductions.