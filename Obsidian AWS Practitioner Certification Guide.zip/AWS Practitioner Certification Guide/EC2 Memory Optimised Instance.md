**X1 -** X1 Instances are optimized for large-scale, enterprise-class, in-memory applications and high-performance databases, and have the lowest price per GiB of RAM among Amazon EC2 instance types.

**R4 -** R4 instances are optimized for memory-intensive applications and offer better price per GiB of RAM than R3. The RAM sizes are a step below the X1s.