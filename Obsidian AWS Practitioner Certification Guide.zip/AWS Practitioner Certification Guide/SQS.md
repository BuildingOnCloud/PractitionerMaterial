Amazon Simple Queue Service (SQS) is a fully managed message queuing service that enables you to decouple and scale microservices, distributed systems, and serverless applications.

Some features of SQS are:

1. Fully managed message queuing service
2. Lets you decouple and scale microservices, distributed systems, and serverless applications
3. Eliminates the complexity and overhead associated with managing and operating message oriented middleware
4. Send, store, and receive messages between software components at any volume, without losing messages or requiring other services to be available.
5. Two types of message queues
	1. **Standard** queues offer maximum throughput, best-effort ordering, and at-least-once delivery.
	2. **SQS FIFO** queues guarantee that messages are processed exactly once, in the exact order that they are sent.