1. [[Scale on demand]]
2. [[Eliminate wasted capacity]]