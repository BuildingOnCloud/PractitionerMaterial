When you use data storage and transfer resources, you pay on a per-gigabyte basis. This pricing model is also known as _tiered_. This means that several different aspects of the service differ in cost. For instance, Amazon S3 has different prices for storage, requests, and data transfer. However, the more you use, the less you pay per gigabyte! The following services fall under the data storage and transfer pricing model.

-   AWS [[Snowball]]
-   [[Amazon Glacier]]
-   AWS [Snowmobile]
-   AWS [[Snowball Edge]]
-   AWS [[Storage Gateway]]
-   Amazon Elastic File System ([[EFS]])
-   Amazon Elastic Block Storage ([[EBS]])
-   Amazon Simple Storage Service ([[S3]])