The AWS Cloud infrastructure is built around Regions and Availability Zones (AZs). 

A Region is a physical location in the world with multiple AZs. 

Availability Zones consist of one or more discrete data centers, each with redundant power and networking, housed in separate facilities that are located on stable flood plains. These AZs offer the abilities to operate production applications and databases which are highly available, fault tolerant, and scalable than would be possible from a single data center. 

The components in AWS Cloud infrastructure are:

-   Availability Zones (AZs)
-   Regions
-   Edge Locations
-   Regional Edge Caches