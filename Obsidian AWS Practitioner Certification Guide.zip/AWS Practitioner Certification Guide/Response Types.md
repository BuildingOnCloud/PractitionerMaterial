There are two types of questions on the examination:
    
-  [[Multiple choice]]
-  [[Multiple response]]