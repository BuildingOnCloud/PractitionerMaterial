1. [[Speed of implementation of services]]
2. [[Experimentation]]
3. [[Innovation]]