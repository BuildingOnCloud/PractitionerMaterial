This is a  **dashboard** that displays up-to-the-minute information about **service** availability in the region.

See https://status.aws.amazon.com