1. R6g
2. R5
3. R5b
4. R5d
5. R4
6. X1e
7. X1
8. Z1d