 

1.  [[Compare and contrast the various pricing models for AWS]]
    
2. [[Recognize the various account structures in relation to AWS billing and pricing]]
    
3. [[Identify resources available for billing support]]