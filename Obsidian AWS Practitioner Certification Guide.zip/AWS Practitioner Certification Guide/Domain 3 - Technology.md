 

1.  [[Define methods of deploying and operating in the AWS Cloud]]
    
2. [[Define the AWS global infrastructure]]
    
3. [[Identify the core AWS services]]
    
4. [[Identify resources for technology support]]