Infrastructure as code is the process of managing and provisioning computer data centers through machine-readable definition files, rather than physical hardware configuration or interactive configuration tools.

There are some software that helps to deploy Infrastructure as code, such as:

-   [[Terraform]]
-   [[Salt Stack]]
-   [[Ansible]]