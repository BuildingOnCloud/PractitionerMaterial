AWS OpsWorks is a configuration management service that helps you configure and operate applications in a cloud enterprise by using Chef. 

There are 2 variants:

1. [[AWS OpsWorks Stacks]]
2. [[AWS OpsWorks for Chef Automate]]

