1. [[Business Unit (BU) Account Structure]]
2. [[Environment Lifecycle Account Structure]]
3. [[Project-Based Account Structure]]
4. [[Hybrid AWS Account Structures]]