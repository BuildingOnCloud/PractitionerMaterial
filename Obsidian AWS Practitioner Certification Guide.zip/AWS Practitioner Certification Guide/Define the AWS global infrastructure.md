The AWS Cloud operates 77 Availability Zones within 24 geographic Regions around the world, with announced plans for 9 more Availability Zones and 3 more Regions in Cape Town, Jakarta, and Milan.

-   [[AWS Regions and Availability Zones]]
-   [[Region & Number of Availability Zones]]
-   [[High Availability Through Multiple Availability Zones]]
-   [[Further Improving Availability by Deploying in Multiple Regions]]
-   [[Meeting Compliance and Data Residency Requirements]]
-   [[Geographic Expansion]]
-   [[Edge Locations]]