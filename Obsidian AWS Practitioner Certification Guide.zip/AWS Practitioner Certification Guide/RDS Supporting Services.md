1. [[AWS Database Migration Service]]
2. [[AWS Schema Conversion Tool]]