You can grant other people permission to administer and use resources in your AWS account without having to share your password or access key. 

Also you can allow users who already have passwords elsewhere—for example, in your corporate Active Directory or with an Internet identity provider—to get access to your AWS account. You can use any identity management solution that supports SAML 2.0.