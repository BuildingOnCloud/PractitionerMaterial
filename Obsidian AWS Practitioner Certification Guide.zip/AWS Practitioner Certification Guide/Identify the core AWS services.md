Here’s a list of the services you should definitely know. But, don’t be surprised if you see questions about others as well:

1. [[EC2]]
2. [[S3]]
3. [[RDS]]
4. [[Lambda]]
5. [[Route 53]]
6. [[SNS]]
7. [[Amazon DevPay]]
8. [[Amazon QuickSight]]
9. [[SQS]]

The level of detail in each question depends on the service. More widely used services may require a bit more knowledge, and others will only require that you know what the service does. For example, EC2 is one of the most important AWS services, so you could be asked questions about different instance types for different scenarios. On the other hand, you may only be asked to choose the best description of a service like CloudFront.

In addition to the traditional services, the exam covers other AWS technology, including the command line interface (CLI) and software development kit (SDK). You may also see questions that overlap with other exam domains. For example, services like AWS Trusted Advisor and AWS Cost Calculator may fall into the technology domain as well as billing and pricing.