 The AWS Certified Cloud Practitioner (CLF-C01) examination is intended for individuals who have the knowledge, skills, and abilities to demonstrate basic knowledge of the AWS platform and take on count of [[Recomendations]].
 
 See [[Exam Content]] to start your journey