**T2 -** T2 instances are Burstable Performance Instances that provide a baseline level of CPU performance with the ability to burst above the baseline. 

**M4 -** M4 instances are the latest generation of General Purpose Instances. This family provides a balance of compute, memory, and network resources, and it is a good choice for many applications.