1.   Sign in and navigate to the AWS Support Center. If prompted, type the email address and password for your account.
2.  Choose **Open a new case**.
3.  On the **Open a new case** page, select **Account and Billing Support** and fill in the required fields on the form.

After you complete the form, you can choose **Web** for an email response, or **Phone** to request a telephone call from an AWS Support representative. Instant messaging support is not available for billing inquiries.