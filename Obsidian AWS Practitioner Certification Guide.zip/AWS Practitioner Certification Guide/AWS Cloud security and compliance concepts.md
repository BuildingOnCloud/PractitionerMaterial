Cloud security at AWS is the highest priority. As an AWS customer, you will benefit from a data center and network architecture built to meet the requirements of the most security-sensitive organizations.

An advantage of the AWS cloud is that it allows customers to scale and innovate, while maintaining a secure environment. Customers pay only for the services they use, meaning that you can have the security you need, but without the upfront expenses, and at a lower cost than in an on-premises environment.

Security Concept to consider:

-   [[Infrastructure Security]]
-   [[Infrastructure Resilience]]
-   [[Data Encryption]]
-   [[Standards and Best Practices]]
-   [[Monitoring and Logging]]
-   [[Identity and Access Control]]
-   [[Security Support]]
-   [[Compliance Assurance Programs]]