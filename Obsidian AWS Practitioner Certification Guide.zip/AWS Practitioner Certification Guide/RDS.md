Amazon Relational Database Service (Amazon RDS) makes it easy to set up, operate, and scale a relational database in the cloud. It provides cost-efficiency and resizable capacity while automating time-consuming administration tasks such as hardware provisioning, database setup, patching and backups.

Amazon RDS is available on several database [[Instance Types]] - optimized for memory, performance or I/O. RDS provides you with six familiar database engines to choose from. Amazon RDS supports encryption at rest and in transit, using keys managed through KMS. Backups are automated, user-initiated snapshots are available and database software is updated automatically.

RDS supports different type of DataBase Engines, such as:

·         Amazon Aurora

·         PostgreSQL

·         MySQL

·         MariaDB

·         Oracle

·         Microsoft SQL Server

AWS have an additional service called [[RDS Supporting Services]]