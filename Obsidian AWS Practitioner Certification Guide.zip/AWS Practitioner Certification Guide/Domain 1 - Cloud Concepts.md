 
1. Define the [[AWS Cloud and its value proposition]]
    
2. Identify aspects of [[AWS Cloud economics]]
    
3. List the different [[Cloud Architecture Design Principles]]