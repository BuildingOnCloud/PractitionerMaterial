Resource tagging can help track expenses throughout the model. Some of the tags that can be useful for billing purposes include:

-   Owner – Used to identify who is responsible for the resource
-   Cost Center/Business Unit – Used to identify the cost center or business unit associated with a resource; typically for cost allocation and tracking
-   Customer – Used to identify a specific client that a particular group of resources serves
-   Project – Used to identify the project(s) the resource supports

Customers can activate an AWS-generated _createdBy_ tag that is automatically applied for cost allocation purposes, to help account for resources that might otherwise go uncategorized. The _createdBy_ tag is available for supported AWS services and resources only, and its value contains data associated with specific API or console events.