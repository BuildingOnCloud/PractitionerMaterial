1. [[Broad set of products]]
2. [[Low to no cost to entry]]