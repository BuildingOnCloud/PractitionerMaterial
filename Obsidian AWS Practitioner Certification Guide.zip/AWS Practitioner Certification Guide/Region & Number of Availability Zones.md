In total, the AWS Cloud operates 77 Availability Zones within 24 geographic Regions around the world.

**US East**

N. Virginia (6), Ohio (3)

**US West**

N. California (3), Oregon (3)

**Asia Pacific**

Mumbai (2), Seoul (2), Singapore (2), Sydney (3), Tokyo (4), Bahrain

**Canada**

Central (2)

**China**

Beijing (2)

**Europe**

Frankfurt (3), Ireland (3), London (2)

**South America**

São Paulo (3)

**AWS GovCloud (US-West) (2)**