Most likely, your organization is not in the business of running data centers, yet a significant amount of time and money is spent doing just that. Amazon Web Services provides a way to acquire and use infrastructure on-demand, so that you pay only for what you consume. This puts more money back into the business, so that you can innovate more, expand faster, and be better positioned to take advantage of new opportunities.

You can reduce your _Total-Cost-of-Ownership (TCO)_ with:
1. [[Pay-As-You-Go Pricing]]

2. [[Tiered Pricing (Use More, Pay Less)]]

3. [[Cost Optimization]]

4. [[Trusted Advisor]]
