The ability to avoid or eliminate unneeded cost or suboptimal resources.

Cost Optimization focuses on avoiding unnecessary costs. Key topics include understanding and controlling where money is being spent, selecting the most appropriate and right number of resource types, analyzing spend over time, and scaling to meet business needs without overspending.

AWS additionally has a [[Cost Explorer]]