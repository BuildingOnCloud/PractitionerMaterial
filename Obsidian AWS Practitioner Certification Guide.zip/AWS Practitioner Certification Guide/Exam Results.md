The AWS Certified Cloud Practitioner ([[Exam CLF-C01]]) examination is a pass or fail exam.

Your results for the examination are reported as a score from 100–1000, with a minimum passing score of 700.

 Your score report contains a table of classifications of your performance at each section level. This information is designed to provide general feedback concerning your examination performance. 
 
 The examination uses a compensatory scoring model, which means that you do not need to “pass” the individual sections, only the overall examination.