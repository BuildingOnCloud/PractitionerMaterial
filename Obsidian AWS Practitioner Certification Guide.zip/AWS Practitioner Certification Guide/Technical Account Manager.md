Your designated Technical Account Manager (TAM) is your primary point of contact who provides guidance, architectural review, and ongoing communication to keep you informed and well prepared as you plan, deploy, and proactively optimize your solutions. 

-   A dedicated voice within AWS to serve as your technical point of contact and advocate
-   Proactive guidance and best practices to help optimize your AWS environment
-   Orchestration and access to the breadth and depth of technical expertise across the full range of AWS