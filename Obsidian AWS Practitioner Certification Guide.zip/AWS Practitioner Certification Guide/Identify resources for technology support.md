The resources available to you for technical support depend on your support plan (Developer Support, Business Support, Enterprise Support)

AWS offers several way to give support:

1. [[AWS Support Ticket]]
2. [[Technical Account Manager]]
3. [[Trusted Advisor]]
4. [[AWS Whitepapers]]
5. [[AWS Service Health Dashboard]]
6. [[AWS Personal Health Dashboard]]