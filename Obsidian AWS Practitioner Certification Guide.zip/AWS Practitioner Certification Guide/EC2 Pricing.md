Amazon EC2 is free to try. There are four ways to pay for Amazon EC2 instances: On-Demand, Reserved Instances, and Spot Instances. You can also pay for Dedicated Hosts which provide you with EC2 instance capacity on physical servers dedicated for your use.

1. [[On-Demand]]
2. [[Spot Instances]]
3. [[Reserved Instances]]
4. [[Per-Second Billing]]