**P2 -** P2 instances are intended for general-purpose GPU compute applications. 

**G3 -** G3 instances are optimized for graphics-intensive applications. The GPU specs are a step below the P2s.

**F1 -** F1 instances offer customizable hardware acceleration with field programmable gate arrays (FPGAs).