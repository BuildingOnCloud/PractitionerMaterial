Configuration management is a systems engineering process for establishing and maintaining consistency of a product's performance, functional, and physical attributes with its requirements, design, and operational information throughout its life.

-   [[Chef]]
-   [[Puppet]]
-   [[Ansible]]