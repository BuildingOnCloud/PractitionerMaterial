Amazon S3 offers a range of storage classes designed for different use cases. Lifecycle transitions can be used to move data between classes, given certain events.

1. [[Amazon S3 Standard]]
2. [[Amazon S3 Standard - Infrequent Access]]
3. [[Amazon Glacier]]