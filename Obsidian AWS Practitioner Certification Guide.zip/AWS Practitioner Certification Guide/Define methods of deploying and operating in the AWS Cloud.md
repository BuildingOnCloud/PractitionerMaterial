Amazon Web Services offers multiple options for provisioning your IT infrastructure and the deployment of your applications. Whether it is a simple three-tier application or a complex set of workloads, the deployment model varies from customer to customer. But with the right techniques, AWS can help you pick the best strategy and tool set for deploying an infrastructure that can handle your workload. **The main principles to remember are AAA - Automate, Automate, Automate.**

1. [[AWS Elastic Beanstalk]]
2. [[AWS CloudFormation]]
3. [[AWS OpsWorks]]
4. [[AWS CodeCommit]]
5. [[AWS CodePipeline]]
6. [[AWS CodeDeploy]]
7. [[Amazon Elastic Container Service]]
8. [[Non-AWS Solutions]]
9. [[General Principles]]