There are two types of instances supported by RDS:

1. [[RDS General Purpose Instance]]
2. [[RDS Memory Optimized Instance]]

