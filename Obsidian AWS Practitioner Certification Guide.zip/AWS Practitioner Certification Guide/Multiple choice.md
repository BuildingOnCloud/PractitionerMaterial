Has one correct response and three incorrect responses (distractors).

