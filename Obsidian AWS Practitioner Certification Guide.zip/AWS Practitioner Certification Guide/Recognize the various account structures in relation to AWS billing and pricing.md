Accounts act as the main billing entity for AWS Resources. Different billing options are available including invoicing, such as "consolidated billing" - letting one account pick up the bill for multiple ‘sub accounts’. With regards to billing we can set up billing alerts, AWS Budgets and automated bill reporting for better insights. We can also utilise tagging for better cost allocation.

1. [[AWS Account Structures]]
2. [[Other Billing and Pricing Considerations]]