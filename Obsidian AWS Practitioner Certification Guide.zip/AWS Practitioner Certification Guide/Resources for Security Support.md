There are two resources available to give support to security improvements:

1.  [[AWS Support]]
2. [[Professional Services]]