**Snowball** is a petabyte-scale data transport solution that uses secure appliances to transfer large amounts of data into and out of the **AWS** cloud. Using **Snowball** addresses common challenges with large-scale data transfers including high network costs, long transfer times, and security concerns.

![[AWS Snowball device.png]]