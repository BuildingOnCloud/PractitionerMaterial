The quickest way to find answers to questions about your bill might be to start with the AWS Knowledge Center.

In addition, all AWS account owners have access to account and billing support free of charge. Only personalized technical support requires a support plan. For more information, visit the AWS Support web site.

It is also worthwhile to know that the AWS Cost Calculator can be used to provide an estimate for your monthly bill. Also Trusted Advisor can help with reducing costs, by suggesting changes to your existing infrastructure.

This section guides you through contacting AWS Support and opening a support case for your billing inquiry, which is the fastest and most direct method for communicating with AWS Support. AWS Support does not publish a direct phone number for reaching a support representative.

1. [[Contacting AWS Support]]
2. [[Support Concierge]]