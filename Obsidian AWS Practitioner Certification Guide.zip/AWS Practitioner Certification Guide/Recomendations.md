1 - Candidates should have a basic understanding of IT services and their uses.

2 - Be Calm on Exam, it's no a speedrun.

3 - Question without Answer automatically is a failed Question.

4 - Read complete all Questions and posible Response