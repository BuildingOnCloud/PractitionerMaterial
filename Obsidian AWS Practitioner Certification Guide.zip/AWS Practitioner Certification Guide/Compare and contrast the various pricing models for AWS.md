The pricing models for AWS are principally "Compute Resources" and "Data Storage and Transfer". However, there are also other pricing models such as request pricing, monthly targeted audience (MTA) pricing, events collected pricing, messages sent pricing, and more.

Below, we’ll explain the differences between the two major pricing models, so before you decide to use a service, be sure to check which one it uses.

1. [[Compute Resources]]
2. [[Data Storage and Transfer]]