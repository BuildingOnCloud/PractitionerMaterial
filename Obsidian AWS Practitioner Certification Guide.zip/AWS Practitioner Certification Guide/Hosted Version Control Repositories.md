Version control hosting solutions are products that host multiple code repositories in the cloud and integrate with, and often provide, online tools that enhance the use of version control systems. Version control hosting solutions allow developers who collaborate on source code to manage a master repository in which they can commit their code changes and pull down new code to their local computers.

-   [[GitHub]]
-   [[GitLab]]
-   [[BitBucket]]