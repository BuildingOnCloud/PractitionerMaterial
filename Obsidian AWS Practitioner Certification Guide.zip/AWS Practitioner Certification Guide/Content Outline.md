
The table below lists the main content domains and their weightings:

| Domain                            | % of Examination  |
|-----------------------------------|-------------------|
| [[Domain 1 - Cloud Concepts]]          | 26%         		|
| [[Domain 2 - Security and Compliance]] | 25%         		|
| [[Domain 3 - Technology]]              | 33%         		|
| [[Domain 4 - Billing and Pricing]]     | 16%         		|

