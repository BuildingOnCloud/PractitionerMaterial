Unlike virtually every other technology infrastructure provider, each AWS Region has multiple Availability Zones and data centers. 

As we’ve learned from running the leading cloud infrastructure technology platform since 2006, customers who care about the availability and performance of their applications want to deploy these applications across multiple Availability Zones in the same region for fault tolerance and low latency. 

Availability Zones are connected to each other with fast and private fiber-optic network, which enables applications to automatically fail-over between Availability Zones without interruption.