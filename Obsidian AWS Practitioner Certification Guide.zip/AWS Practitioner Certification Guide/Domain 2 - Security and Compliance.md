 

1.  Define the [[AWS Shared Responsibility Model]]
    
2. Define the [[AWS Cloud security and compliance concepts]]
    
3. Identify [[AWS access management capabilities]]
    
4. Identify [[Resources for Security Support]]