Included as part of the Enterprise Support plan, the Support Concierge is a billing and account expert who provides quick and efficient analysis and assistance. Your assigned Concierge addresses all non-technical billing and account level inquiries - freeing up your time to run your business.

-   A primary contact to help manage AWS billing and account-level services

-   Proactive guidance and best practices for billing allocation, consolidation of accounts, and root-level account security

-   Direct access to a billing advocate for payment inquiries, cost reports, service limits, and bulk purchases