When you use compute resources, you pay on an hourly basis from the time you launch a resource until the time you terminate it. You can also get volume discounts up to 10% when you reserve more. The following Amazon Web Services fall under the compute resources pricing model.

-   [[Lambda]]
-   [[Lightsail]]
-   [[Elastic Load Balancing]]
-   [[EC2 Container Registry]]
-   [[VPC]]
-   [[EC2]]